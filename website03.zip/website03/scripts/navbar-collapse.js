$('.navbar-collapse a').click(function(){
    $(".navbar-collapse").collapse('hide');
});