document.getElementById("form-zip").addEventListener("input", validateForm);

// Checks for name null if null -> shows warning message
function validateForm() {

  let valid = true;

  // Var dump
  let zip = document.getElementById("form-zip");
  let submit = document.getElementById("form-submit");
  let zipAlert = document.getElementById("alert-zip-incorrect");
  let zipLength = document.getElementById("form-zip").value;
  let zipRequired = document.getElementById("invalid-zip");

  //Check zip for 98030, 98031, 98032, 98042, 98058
  if (zipLength.length > 4 && (zip.value != "98030" && zip.value != "98031" && zip.value != "98032" && zip.value != "98042" && zip.value != "98058")) {
      zip.className = "form-control border-danger";
      submit.disabled = true;
      submit.className = "btn btn-danger btn-lg float-right";
      zipAlert.style.display = "inline-block";
      zipRequired.style.display = "inline-block";
      return false;
  } else if (zipLength.length > 4 && !(zip.value != "98030" && zip.value != "98031" && zip.value != "98032" && zip.value != "98042" && zip.value != "98058")) {
    // Shows green font for go
    zip.className = "form-control border-success";
    submit.disabled = false;
    submit.className = "btn btn-light btn-lg float-right";
    zipAlert.style.display = "none";
    zipRequired.style.display = "none";
    return true;
  } else if (zip.value == "") {
    zip.className = "form-control border-white";
    submit.disabled = false;
    submit.className = "btn btn-light btn-lg float-right";
    zipAlert.style.display = "none";
    zipRequired.style.display = "none";
    return true;
  }

  return valid;
}

//form-submit form-zip

//document.getElementById("myDIV").style.display = "none"; & block

//form-first-name  form-last-name

//invalid-fName   invalid-lName    invalid-email    invalid-number   invalid-zip


// alert-zip   alert-contact   alert-name