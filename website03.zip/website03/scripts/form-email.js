// Catches when form submitted
document.getElementById("form-submit").addEventListener("click", validateForm);

// Checks for email/phone null if null -> shows warning message
function validateForm() {
  let valid = true;

  //Check email/phone for null
  let emailRequired = document.getElementById("invalid-email");
  let phoneRequired = document.getElementById("invalid-number");
  let email = document.getElementById("form-email").value;
  let phone = document.getElementById("form-phone").value;
  let alertContact = document.getElementById("alert-contact");

  // Flips error for corresponding email/phone element
  if (email == "") {
    emailRequired.style.display = "block"; 
    alertContact.style.display = "block";
    valid = false;
  } 
  
  if (phone == "") {
    phoneRequired.style.display = "block"; 
    alertContact.style.display = "block"; 
    valid = false;
  } 

  if ((phone != "" && email == "") || (email != "" && phone == "") || (email != ""  & phone != "")) {
    phoneRequired.style.display = "none";
    emailRequired.style.display = "none";
    alertContact.style.display = "none";
    valid = true;
  } 

  /* TODO - NUMBER VALIDATION
  var validNumber = /^\d{10}$/;
  if((inputtxt.value.match(validNumber)) {

  } else {

  } */

  return valid;
}



//document.getElementById("myDIV").style.display = "none"; & block

//form-first-name  form-last-name

//invalid-fName   invalid-lName    invalid-email    invalid-number   invalid-zip


// alert-zip   alert-contact   alert-name