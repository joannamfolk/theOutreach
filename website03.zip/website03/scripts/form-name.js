// Catches when form submitted
document.getElementById("form-submit").addEventListener("click", validateForm);

// Checks for name null if null -> shows warning message
function validateForm() {
  let valid = true;

  //Check name for null
  let fNameRequired = document.getElementById("invalid-fName");
  let lNameRequired = document.getElementById("invalid-lName");
  let fName = document.getElementById("form-first-name").value;
  let lName = document.getElementById("form-last-name").value;
  let nameAlert = document.getElementById("alert-name");

  // Flips error for corresponding name element
  if (fName == "") {
    fNameRequired.style.display = "block";
    nameAlert.style.display = "block";
    valid = false;
  } 

  else if (fName != "" && lName == "") {
    fNameRequired.style.display = "none";
    lNameRequired.style.display = "block"; 
    nameAlert.style.display = "block";
    valid = false;
  }
  
  if (lName == "") {
    lNameRequired.style.display = "block"; 
    nameAlert.style.display = "block";
    valid = false;
  } 

  else if (lName != "" && fName == "") {
    lNameRequired.style.display = "none";
    fNameRequired.style.display = "block";
    nameAlert.style.display = "block";
    valid = false;
  } 

  if (lName != ""  & fName != "") {
    // Makes name warning invisible
    fNameRequired.style.display = "none";
    lNameRequired.style.display = "none";
    nameAlert.style.display = "none";
    valid = true;

  }

  return valid;
}