// TODO - FIX SUBMIT SO IT DOESN'T ALLOW PHP W/O TRUE
// Checks if any alerts showing, if so it doesn't allow for submit       
let submit = document.getElementById("form-submit");

submit.addEventListener("click", validate);

function validate() {
  let valid = true;

  let nameAlert = document.getElementById("alert-name");
  let contactAlert = document.getElementById("alert-contact");
  let zipAlert = document.getElementById("alert-zip");
  let checkAlert = document.getElementById("alert-check");
  let servicesForm = document.getElementById("services-form");
  let submitConfirmation = document.getElementById("form-finished");
  let formSubmit = document.getElementById("form-switch");

  // TODO - FIGURE THIS OUT
  //Check name
 if (nameAlert.style.display == "block" || contactAlert.style.display == "block" || zipAlert.style.display == "block" || checkAlert.style.display == "block") {
    submitConfirmation.style.display = "none";
    valid = false;
    } else {
      formSubmit.style.display = "none";
      submitConfirmation.style.display = "block";
      valid = true;
    }

  return valid;
}

/* Checks if any alerts showing, if so it doesn't allow for submit       
let submit = document.getElementById("form-submit");

submit.addEventListener("click", validate);

function validate() {
  let servicesForm = document.getElementById("services-form");
  let submitConfirmation = document.getElementById("form-finished");
  let formSubmit = document.getElementById("form-switch");

  let fname = document.getElementById("form-first-name");
  let lname = document.getElementById("form-last-name");
  let email = document.getElementById("form-email");
  let phone = document.getElementById("form-phone");
  let zip = document.getElementById("form-zip");
  let without = document.getElementById("btn-without");
  
  let util = document.getElementById("chk-utility");
  let rent = document.getElementById("chk-rent");
  let gas = document.getElementById("chk-gas");
  let thrift = document.getElementById("chk-thrift");
  let id = document.getElementById("chk-id");
  let goods = document.getElementById("chk-goods");
  let other = document.getElementById("text-other");

  let nameAlert = document.getElementById("alert-name");
  let contactAlert = document.getElementById("alert-contact");
  let zipAlert = document.getElementById("alert-zip");
  let checkAlert = document.getElementById("alert-check");

  // TODO - FIGURE THIS OUT
  //Check name
 if (fname.value == "" || lname.value == "" || (((email.value != "" || phone.value == "")) || ((email.value == "" || phone.value != ""))) || ((zip.value == "" || without.checked != true) || (zip.value == "" || without.checked != true)) || nameAlert.style.display == "block" || contactAlert.style.display == "block" || zipAlert.style.display == "block" || checkAlert.style.display == "block" && ((util.value == false || rent.value == false || gas.value == false || thrift.value == false || id.value == false || goods.value == false || other.value == ""))) {
    submitConfirmation.style.display = "none";
    document.getElementById("services-form").scrollIntoView()
    valid = false;
    } else {
      formSubmit.style.display = "none";
      document.getElementById("form-finished").scrollIntoView()
      submitConfirmation.style.display = "block";
      valid = true;
    }

  return valid;
}*/